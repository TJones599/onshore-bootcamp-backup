﻿

namespace WordSearch_dark_souls_mode
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WindowWidth = Console.LargestWindowWidth - 80;
            Console.WriteLine("Enter a Sentence: ");
            string sentence = Console.ReadLine();

            StringBuilder sb = new StringBuilder();

            foreach (char c in sentence)
            {
                if (!char.IsPunctuation(c))
                    sb.Append(c);
            }

            sentence = sb.ToString();
            sentence = sentence.ToUpper();


            string[] allWords = sentence.Split(' ', '.', '!', '?', '"', ':', ';');
            string[] testWords = allWords.Distinct().ToArray();
            int[] wordOccurance = new int[testWords.Length];

            for (int uniqueWords = 0; uniqueWords < testWords.Length; uniqueWords++)
            {
                for (int wordCount = 0; wordCount < allWords.Length; wordCount++)
                {
                    if (testWords[uniqueWords].Equals(allWords[wordCount], StringComparison.CurrentCultureIgnoreCase))
                    {
                        wordOccurance[uniqueWords]++;
                    }
                }
            }
            Console.WriteLine();
            for (int wordIndex = 0; wordIndex < testWords.Length; wordIndex++)
            {
                Console.WriteLine("{0} ({1})", testWords[wordIndex], wordOccurance[wordIndex]);
            }

            Console.ReadKey();
        }
    }
}
