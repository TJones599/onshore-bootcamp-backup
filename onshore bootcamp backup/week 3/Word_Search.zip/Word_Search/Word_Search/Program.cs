﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Word_Search
{
    using System.Threading;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please Enter Sentence: ");
            string userSentence = Console.ReadLine();
            Console.WriteLine("Please select a word: ");
            string findWord = Console.ReadLine();

            string[] words = userSentence.Split(' ');
            
            int wordCount = 0;
            foreach(string word in words)
            {
                if (word.Equals(findWord,StringComparison.CurrentCultureIgnoreCase))
                {

                    wordCount++;
                }
            }
            Console.Clear();
            Console.WriteLine("The word \"" + findWord + "\" occured " + wordCount + " times.");

            for (int i = 0; i < words.Length; i++)
            {
                if (words[i] == findWord)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write(words[i]+" ");
                    Console.ResetColor();
                }
                else
                    Console.Write(words[i]+" ");
            }
            Console.WriteLine();
            /*
            for (int i = 0; i < words.Length; i++)
            {
                if(words[i]==findWord)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(words[i]);
                    Console.ResetColor();
                }
                else
                    Console.WriteLine(words[i]);
            }
            */
            Console.ReadKey();
        }
    }
}
