﻿namespace Gocery_List
{   using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.IO;
    using System.Reflection;
    using System.Media;

    class Program
    {
        public static void TaDa()
        {
            SoundPlayer soundplayer = new SoundPlayer();
            soundplayer.SoundLocation = soundPath;
            soundplayer.Load();
            soundplayer.Play();
        }
        public static decimal ObtainDecimalInput(string message)
        {
            string textInput = "";
            decimal number = 0;
            bool invalidInput = true;

            do
            {
                Console.Write(message);
                textInput = Console.ReadLine();
                invalidInput = decimal.TryParse(textInput, out number);
            } while (!invalidInput);

            return number;
        }
        public static void EmptyFile(string filePath)
        {
            StreamWriter clearList = new StreamWriter(filePath, false);
            clearList.WriteLine("");
            clearList.Close();
            clearList.Dispose();
        }
        public static void ReadList(string filePath)
        {
            Console.Clear();
            TaDa();
            Console.WriteLine("Grocery List");
            StreamReader reader = new StreamReader(filePath, true);
            Console.WriteLine(reader.ReadToEnd());
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("<Press Enter To Go Back To The Main Page>");
            Console.ResetColor();
            Console.ReadKey();
            reader.Close();
            reader.Dispose();
        }

        public static void AddItem(string filePath)
        {
            Console.Write("Item Name: ");
            string name = Console.ReadLine();
            Console.Write("Item Amount: ");
            string quantity = Console.ReadLine();
            decimal price = ObtainDecimalInput("Item Price: ");

            StreamWriter addNewItem = new StreamWriter(filePath, true);
            //addNewItem.WriteLine($"{name} {quantity} {price}");
            addNewItem.WriteLine("{0,-10} {1, -10} {2, -10:C}", name, quantity, price);
            addNewItem.Close();
            addNewItem.Dispose();
        }

        private static string soundPath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Ta Da-SoundBible.com-1884170640.wav";

        static void Main(string[] args)
        {
            

            bool continueOrExit = true;
            string filePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)+@"\Grocery_List";
            do
            {

                Console.Clear();
                Console.WriteLine("What would you like to do?");
                Console.WriteLine("");
                Console.WriteLine("1.) Add items to your list");
                Console.WriteLine("2.) Read your list");
                Console.WriteLine("3.) Clear your list");
                Console.WriteLine("4.) Exit program");

                ConsoleKey readOrWrite = Console.ReadKey(true).Key;
                switch (readOrWrite)
                {
                    case ConsoleKey.D1:
                    case ConsoleKey.NumPad1:
                        AddItem(filePath);
                        break;

                    case ConsoleKey.D2:
                    case ConsoleKey.NumPad2:
                        ReadList(filePath);
                        break;

                    case ConsoleKey.D3:
                    case ConsoleKey.NumPad3:
                        EmptyFile(filePath);
                        break;

                    case ConsoleKey.D4:
                    case ConsoleKey.NumPad4:
                        continueOrExit = false;
                        break;
                }
            } while (continueOrExit);
        }
    }
}
