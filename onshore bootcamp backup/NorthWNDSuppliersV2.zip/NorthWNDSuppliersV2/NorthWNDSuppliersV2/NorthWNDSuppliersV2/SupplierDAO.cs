﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using NorthWNDSuppliersV2.Models;
using System.Configuration;

namespace NorthWNDSuppliersV2
{
   public class SupplierDAO
    {
        public readonly string connectionString;

        public SupplierDAO(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public DataTable ObtainTableInfo()
        {
            DataTable supplierTable = new DataTable();
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand viewSupplierTable = new SqlCommand("VIEW_SUPPLIER_TABLE", sqlConnection))
                {
                    viewSupplierTable.CommandType = System.Data.CommandType.StoredProcedure;
                    viewSupplierTable.CommandTimeout = 90;

                    sqlConnection.Open();
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(viewSupplierTable))
                    {
                        sqlDataAdapter.Fill(supplierTable);
                    }

                    sqlConnection.Close();
                    return supplierTable;
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        public DataTable ObtainSupplierSingle(int ID)
        {
            DataTable supplierTable = new DataTable();
            string connectionString = ConfigurationManager.ConnectionStrings["dataSource"].ConnectionString;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand viewSupplierByID = new SqlCommand("VIEW_ROW_BY_ID", sqlConnection))
                {
                    viewSupplierByID.CommandType = System.Data.CommandType.StoredProcedure;
                    viewSupplierByID.CommandTimeout = 90;

                    viewSupplierByID.Parameters.AddWithValue("SupplierID", ID);

                    sqlConnection.Open();
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(viewSupplierByID))
                    {
                        sqlDataAdapter.Fill(supplierTable);
                    }

                    sqlConnection.Close();
                }
                return supplierTable;
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        public void CreateNewSupplier(Supplier suppInfo)
            {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand updateSupplier = new SqlCommand("CREATE_SUPPLIER", sqlConnection))
                {
                    updateSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                    updateSupplier.CommandTimeout = 90;
                    
                    updateSupplier.Parameters.AddWithValue("CompanyName", suppInfo.CompanyName);
                    updateSupplier.Parameters.AddWithValue("ContactName", suppInfo.ContactName);
                    updateSupplier.Parameters.AddWithValue("ContactTitle", suppInfo.ContactTitle);
                    updateSupplier.Parameters.AddWithValue("Address", suppInfo.Address);
                    updateSupplier.Parameters.AddWithValue("City", suppInfo.City);
                    updateSupplier.Parameters.AddWithValue("Region", suppInfo.Region);
                    updateSupplier.Parameters.AddWithValue("PostalCode", suppInfo.PostalCode);
                    updateSupplier.Parameters.AddWithValue("Country", suppInfo.Country);
                    updateSupplier.Parameters.AddWithValue("Phone", suppInfo.Phone);
                    updateSupplier.Parameters.AddWithValue("Fax", suppInfo.Fax);
                    updateSupplier.Parameters.AddWithValue("HomePage", suppInfo.HomePage);

                    sqlConnection.Open();
                    updateSupplier.ExecuteNonQuery();

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        public void UpdateInformation(Supplier suppInfo, int ID)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand updateSupplier = new SqlCommand("UPDATE_SUPPLIER_INFO", sqlConnection))
                {
                    updateSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                    updateSupplier.CommandTimeout = 90;

                    updateSupplier.Parameters.AddWithValue("supplierID", ID);
                    updateSupplier.Parameters.AddWithValue("CompanyName", suppInfo.CompanyName);
                    updateSupplier.Parameters.AddWithValue("ContactName", suppInfo.ContactName);
                    updateSupplier.Parameters.AddWithValue("ContactTitle", suppInfo.ContactTitle);
                    updateSupplier.Parameters.AddWithValue("Address", suppInfo.Address);
                    updateSupplier.Parameters.AddWithValue("City", suppInfo.City);
                    updateSupplier.Parameters.AddWithValue("Region", suppInfo.Region);
                    updateSupplier.Parameters.AddWithValue("PostalCode", suppInfo.PostalCode);
                    updateSupplier.Parameters.AddWithValue("Country", suppInfo.Country);
                    updateSupplier.Parameters.AddWithValue("Phone", suppInfo.Phone);
                    updateSupplier.Parameters.AddWithValue("Fax", suppInfo.Fax);
                    updateSupplier.Parameters.AddWithValue("HomePage", suppInfo.HomePage);

                    sqlConnection.Open();
                    updateSupplier.ExecuteNonQuery();

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        public void DeleteSupplier(int ID)
        {
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand deleteSupplier = new SqlCommand("DELETE_SUPPLIER", sqlConnection))
                {
                    deleteSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                    deleteSupplier.CommandTimeout = 90;
                    deleteSupplier.Parameters.AddWithValue("SupplierID", ID);

                    sqlConnection.Open();
                    deleteSupplier.ExecuteNonQuery();

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }
    }
}
