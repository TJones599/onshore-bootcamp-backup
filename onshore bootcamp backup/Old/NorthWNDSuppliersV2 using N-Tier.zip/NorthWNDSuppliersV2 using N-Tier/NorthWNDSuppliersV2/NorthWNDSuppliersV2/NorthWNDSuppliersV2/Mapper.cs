﻿using NorthWNDSuppliers_DAL.Models;
using NorthWNDSuppliersV2.Models;
using System.Collections.Generic;

namespace NorthWNDSuppliersV2
{
    public static class Mapper
    {
        public static SupplierPO SupplierDOtoSupplierPO(SupplierDO from)
        {
            SupplierPO to = new SupplierPO();

            to.SupplierID = from.SupplierID;
            to.CompanyName = from.CompanyName;
            to.ContactName = from.ContactName;
            to.ContactTitle = from.ContactTitle;
            to.Address = from.Address;
            to.City = from.City;
            to.Region = from.Region;
            to.PostalCode = from.PostalCode;
            to.Country = from.Country;
            to.Phone = from.Phone;
            to.Fax = from.Fax;
            to.HomePage = from.HomePage;

            return to;
        }
        public static SupplierDO SupplierPOtoSupplierDO(SupplierPO from)
        {
            SupplierDO to = new SupplierDO();

            to.SupplierID = from.SupplierID;
            to.CompanyName = from.CompanyName;
            to.ContactName = from.ContactName;
            to.ContactTitle = from.ContactTitle;
            to.Address = from.Address;
            to.City = from.City;
            to.Region = from.Region;
            to.PostalCode = from.PostalCode;
            to.Country = from.Country;
            to.Phone = from.Phone;
            to.Fax = from.Fax;
            to.HomePage = from.HomePage;

            return to;
        }

        public static List<SupplierPO> DOListToPOList(List<SupplierDO> from)
        {
            List<SupplierPO> toFull = new List<SupplierPO>();

            for (int i = 0; i < from.Count; i++)
            {
                SupplierPO to = new SupplierPO();
                to.SupplierID = from[i].SupplierID;
                to.CompanyName = from[i].CompanyName;
                to.ContactName = from[i].ContactName;
                to.ContactTitle = from[i].ContactTitle;
                to.Address = from[i].Address;
                to.City = from[i].City;
                to.Region = from[i].Region;
                to.PostalCode = from[i].PostalCode;
                to.Country = from[i].Country;
                to.Phone = from[i].Phone;
                to.Fax = from[i].Fax;
                to.HomePage = from[i].HomePage;
                toFull.Add(to);
            }

            return toFull;
        }
    }
}

