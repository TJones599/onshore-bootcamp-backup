﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using System.IO;

namespace NorthWindSuppliers
{
    class Program
    {
        private static readonly string filePath = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        private static void DeleteSuppliers()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["dataSource"].ConnectionString;

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand deleteSupplier = new SqlCommand("DELETE_SUPPLIER", sqlConnection))
                {
                    deleteSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                    deleteSupplier.CommandTimeout = 90;

                    Console.WriteLine("Which supplier would you like to delete?");

                    string supplierID = Console.ReadLine();

                    deleteSupplier.Parameters.AddWithValue("SupplierID", supplierID);

                    sqlConnection.Open();
                    deleteSupplier.ExecuteNonQuery();

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        private static void UpdateSuppliers()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["dataSource"].ConnectionString;
            string[] ColumnNames = File.ReadAllLines(filePath + @"\ColumnsInSuppliers.txt");

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand updateSupplier = new SqlCommand("UPDATE_SUPPLIER_INFO", sqlConnection))
                {
                    updateSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                    updateSupplier.CommandTimeout = 90;


                    foreach (string name in ColumnNames)
                    {
                        Console.WriteLine("Please enter " + Convert.ToString(name) + ": ");

                        if (name == "HomePage")
                        {
                            updateSupplier.Parameters.Add(name, SqlDbType.NText);
                        }
                        else if (name == "SupplierID")
                        {
                            updateSupplier.Parameters.Add(name, SqlDbType.Int);
                        }
                        else
                        {
                            updateSupplier.Parameters.Add(name, SqlDbType.NVarChar);
                        }

                        updateSupplier.Parameters[name].Value = Console.ReadLine();
                    }

                    sqlConnection.Open();
                    updateSupplier.ExecuteNonQuery();

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        private static void CreateSuppliers()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["dataSource"].ConnectionString;
            string[] ColumnNames = File.ReadAllLines(filePath + @"\ColumnsInSuppliers.txt");

            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                {
                    using (SqlCommand updateSupplier = new SqlCommand("CREATE_SUPPLIER", sqlConnection))
                    {
                        updateSupplier.CommandType = System.Data.CommandType.StoredProcedure;
                        updateSupplier.CommandTimeout = 90;


                        foreach (string name in ColumnNames)
                        {
                            if (name != "SupplierID")
                            {
                                Console.WriteLine("Please enter " + Convert.ToString(name) + ": ");

                                if (name == "HomePage")
                                {
                                    updateSupplier.Parameters.Add(name, SqlDbType.NText);
                                }
                                else
                                {
                                    updateSupplier.Parameters.Add(name, SqlDbType.NVarChar);
                                }

                                updateSupplier.Parameters[name].Value = Console.ReadLine();
                            }
                        }

                        sqlConnection.Open();
                        updateSupplier.ExecuteNonQuery();

                        sqlConnection.Close();
                    }
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }
        }

        private static void ViewSuppliers()
        {
            DataTable supplierTable = new DataTable();
            string connectionString = ConfigurationManager.ConnectionStrings["dataSource"].ConnectionString;
            try
            {
                using (SqlConnection sqlConnection = new SqlConnection(connectionString))
                using (SqlCommand viewSupplierTable = new SqlCommand("VIEW_SUPPLIER_TABLE", sqlConnection))
                {
                    viewSupplierTable.CommandType = System.Data.CommandType.StoredProcedure;
                    viewSupplierTable.CommandTimeout = 90;

                    sqlConnection.Open();
                    using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(viewSupplierTable))
                    {
                        sqlDataAdapter.Fill(supplierTable);
                    }

                    sqlConnection.Close();
                }
            }
            catch (SqlException sqlEx)
            {
                throw sqlEx;
            }

            foreach (DataRow row in supplierTable.Rows)
            {
                foreach (DataColumn column in supplierTable.Columns)
                {
                    Console.WriteLine(column.ColumnName + ": " + row[column]);
                }
                Console.WriteLine();
            }
        }

        private static int GetIntInput()
        {
            int num;
            bool invalidEntry = true;

            int cTop = Console.CursorTop;
            int cLeft = Console.CursorLeft;

            do
            {
                invalidEntry = (!int.TryParse(Console.ReadLine(), out num));

                if (invalidEntry)
                {
                    Console.SetCursorPosition(cLeft, cTop);
                    Console.WriteLine("Invalid Entry. Input Number:");
                }
            } while (invalidEntry);

            return num;
        }

        static void Main(string[] args)
        {
            try
            {
                bool wrongNum = false;
                bool exit = false;

                do
                {
                    Console.WriteLine("We are in the Supplier table of NORTHWIND. \nWould you like to: \n\t" +
                        "1) View all suppliers.\n\t" +
                        "2) Update an existing supplier information.\n\t" +
                        "3) Create a new supplier.\n\t" +
                        "4) Delete a supplier.\n\t" +
                        "5) Exit this program.");

                    //Ask to put 1-5, if not.
                    if (wrongNum)
                    {
                        Console.WriteLine("\nInput number 1-5:");
                        wrongNum = false;
                    }

                    int menuChoice = GetIntInput();
                    switch (menuChoice)
                    {
                        case 1:
                            ViewSuppliers();
                            Console.WriteLine("Press any key to return.");
                            Console.ReadKey();
                            break;
                        case 2:
                            UpdateSuppliers();
                            break;
                        case 3:
                            CreateSuppliers();
                            break;
                        case 4:
                            DeleteSuppliers();
                            break;
                        case 5:
                            exit = true;
                            break;
                        default:
                            Console.Clear();
                            wrongNum = true;
                            break;
                    }
                } while (exit == false);
            }
            catch (SqlException sqlEx)
            {
                Console.WriteLine("fucked up");
                Console.ReadKey();
            }
            finally
            {

            }
        }
    }
}
